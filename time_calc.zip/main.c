#include <stdio.h>

#include "time_calc.h"

int main() {
	
	//25 characters should be more than enough for example Jan 01 2026 would be 12 in length
	//and adding time would be 06:00 would be 18
	
    char current[25]; 
    char plus[25];
    char minus[25];
    int plusDays, minusDays;
	
	
	//CURRENTLY SET TO +/-50 DAYS FROM CURRENT DAY CAN UNCOMMENT BELOW AND REMOVE THE PLUSDAYS AND MINUSDAYS BELOW TO TRY DIFFERENT DAYS.
	
	//current calc will have to get the code for the potentiometers to implement properly.
	plusDays = 50;
	minusDays = 50;


    //DEBUGGING FOR MANUAL ENTRY IF WANTED (and probably what will be used with the project using voltage readings from the pots).
    /*printf("Enter number of days to add (+): ");
    scanf("%d", &pluDays);

    printf("Enter number of days to subtract (-): ");
    scanf("%d", &minuDays);
	*/

    timeCalculation(current, plus, minus, plusDays, minusDays);

	//DEBUGGING
    printf("Current date:        %s\n", current);
    printf("Date + %d days:      %s\n", plusDays, plus);
    printf("Date - %d days:      %s\n", minusDays, minus);

    return 0;
}